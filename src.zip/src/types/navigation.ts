export type RootStackParamList = {
    Auth: undefined;
    KeySetup: { uid: string; publicKey: string | null };
  };
  