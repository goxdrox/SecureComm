import React from 'react';
import MainTabs from '../navigation/MainTabs'; // Import the MainTabs component

const HomeScreen = () => {
  return <MainTabs />;
};

export default HomeScreen;
